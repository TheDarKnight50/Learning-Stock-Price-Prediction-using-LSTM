# Machine Learning and Stock Market Assignment: Problem Statements

This assignment includes 3 questions. TThe first two deals with ML whereas third one tests your understanding about Stock Market.

---

## 1. Linear Regression
Complete the python code for the functions in ```q1.py```.

---

## 2. Logistic Regression
Complete the python code for the functions in ```q2.py```.

---

## 3. Stock Market
Summarize the knowledge you have learned in the introductory lecture in a ```submission_NAME_ROLL.txt``` file in 100-120 words.

---
